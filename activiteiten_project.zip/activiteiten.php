<?php
$servername = "127.0.0.1";
$port = "3306";
$username = "root";
$password = "admin";
$dbname = "activiteiten_app";

try {
    $conn = new PDO("mysql:host=$servername;port=$port;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Controleer of er een sortering is gekozen
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'titel'; // standaard alfabetisch
    if ($sort == 'score') {
        $sql = "SELECT * FROM activiteiten ORDER BY score DESC";
    } else {
        $sql = "SELECT * FROM activiteiten ORDER BY titel ASC";
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $activiteiten = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // JSON output (voor frontend)
    header('Content-Type: application/json');
    echo json_encode($activiteiten);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

