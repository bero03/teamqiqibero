<?php
require 'config.php';
// list.php?sort=alpha|score
$sort = $_GET['sort'] ?? 'alpha';

// Build query selecting average score and a thumbnail (first photo)
$sql = "SELECT a.id, a.title, a.description, a.created_at,
  COALESCE(AVG(r.score),0) AS avg_score,
  (SELECT filename FROM photos p WHERE p.activity_id = a.id ORDER BY p.id LIMIT 1) AS thumb
  FROM activities a
  LEFT JOIN ratings r ON r.activity_id = a.id
  GROUP BY a.id";

if ($sort === 'score') {
    $sql .= " ORDER BY avg_score DESC, a.title ASC";
} else {
    $sql .= " ORDER BY a.title ASC";
}

$stmt = $pdo->query($sql);
$activities = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Activiteiten - overzicht</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body{font-family:Arial,Helvetica,sans-serif;padding:20px}
    .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
    .card{background:#fff;padding:12px;border-radius:6px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
    .thumb{height:160px;background:#eee;display:flex;align-items:center;justify-content:center;overflow:hidden}
    .thumb img{width:100%;height:100%;object-fit:cover}
    .meta{display:flex;justify-content:space-between;align-items:center;margin-top:8px}
  </style>
</head>
<body>
  <h1>Activiteiten</h1>
  <div style="margin-bottom:12px">
    Sorteren:
    <a href="?sort=alpha">Alfabet</a> | <a href="?sort=score">Score</a>
    &nbsp; &nbsp; <a href="add_activity.php">+ Nieuwe activiteit</a>
  </div>

  <div class="grid">
  <?php foreach($activities as $a): ?>
    <div class="card">
      <div class="thumb">
        <?php if ($a['thumb']): ?>
          <img src="images/<?php echo htmlspecialchars($a['thumb']); ?>" alt="">
        <?php else: ?>
          <div style="color:#999">Geen foto</div>
        <?php endif; ?>
      </div>
      <h3><?php echo htmlspecialchars($a['title']); ?></h3>
      <p><?php echo htmlspecialchars(substr($a['description'] ?? '',0,120)); ?></p>
      <div class="meta">
        <div>Score: <?php echo number_format($a['avg_score'],2); ?></div>
        <div><a href="detail.php?id=<?php echo $a['id']; ?>">Bekijk details ▾</a></div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>

</body>
</html>