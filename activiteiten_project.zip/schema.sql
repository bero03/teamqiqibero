-- schema.sql
-- Run this in phpMyAdmin or via mysql CLI to create the DB and tables
CREATE DATABASE IF NOT EXISTS activiteiten_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE activiteiten_app;

CREATE TABLE IF NOT EXISTS activities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS photos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  activity_id INT NOT NULL,
  filename VARCHAR(255) NOT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ratings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  activity_id INT NOT NULL,
  score TINYINT NOT NULL CHECK (score BETWEEN 1 AND 5),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- sample data
INSERT INTO activities (title, description) VALUES
('Activiteit A', 'Beschrijving A'),
('Activiteit B', 'Beschrijving B'),
('Activiteit C', 'Beschrijving C');

-- optional: insert sample ratings
INSERT INTO ratings (activity_id, score) VALUES
(1,5),(1,4),(2,3),(3,4);

-- optional: add placeholder photos filenames (you can upload real files later)
INSERT INTO photos (activity_id, filename) VALUES
(1, 'placeholder1.jpg'),
(2, 'placeholder2.jpg'),
(3, 'placeholder3.jpg');
