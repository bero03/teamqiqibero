<?php
require 'config.php';
// Simple add activity form + multiple photos upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $desc = $_POST['description'] ?? '';
    if (trim($title) === '') { $error = 'Titel is vereist.'; }
    else {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO activities (title, description) VALUES (?, ?)");
        $stmt->execute([$title, $desc]);
        $activity_id = $pdo->lastInsertId();
        
        // handle uploads
        if (!empty($_FILES['photos']) && is_array($_FILES['photos']['name'])) {
            $uploadDir = __DIR__ . '/images/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            for ($i=0;$i<count($_FILES['photos']['name']);$i++) {
                if ($_FILES['photos']['error'][$i] !== UPLOAD_ERR_OK) continue;
                $tmp = $_FILES['photos']['tmp_name'][$i];
                $orig = basename($_FILES['photos']['name'][$i]);
                $ext = pathinfo($orig, PATHINFO_EXTENSION);
                $filename = uniqid('act_') . '.' . $ext;
                move_uploaded_file($tmp, $uploadDir . $filename);
                $stmt = $pdo->prepare("INSERT INTO photos (activity_id, filename) VALUES (?, ?)");
                $stmt->execute([$activity_id, $filename]);
            }
        }
        $pdo->commit();
        header('Location: list.php'); exit;
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Nieuwe activiteit</title></head>
<body>
  <a href="list.php">← Terug</a>
  <h1>Nieuwe activiteit toevoegen</h1>
  <?php if (!empty($error)) echo '<div style="color:red">'.htmlspecialchars($error).'</div>'; ?>
  <form method="post" enctype="multipart/form-data">
    <div><label>Titel<br><input type="text" name="title" required></label></div>
    <div><label>Beschrijving<br><textarea name="description"></textarea></label></div>
    <div><label>Foto's (meerdere mogelijk)<br><input type="file" name="photos[]" accept="image/*" multiple></label></div>
    <div><button type="submit">Opslaan</button></div>
  </form>
</body>
</html>