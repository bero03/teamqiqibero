<?php
// setup.php - initialize database and tables for the activities app
// It uses the credentials in config.php if possible.

// Load config values if file exists (we only need host/user/pass)
$dbHost = '127.0.0.1';
$dbUser = 'root';
$dbPass = '';
$dbName = 'activiteiten_app';

if (file_exists(__DIR__ . '/config.php')) {
    // try to parse values from config.php safely
    $cfg = file_get_contents(__DIR__ . '/config.php');
    if (preg_match("/\$DB_HOST\s*=\s*['\"]([^'\"]+)['\"];?/", $cfg, $m)) $dbHost = $m[1];
    if (preg_match("/\$DB_USER\s*=\s*['\"]([^'\"]+)['\"];?/", $cfg, $m)) $dbUser = $m[1];
    if (preg_match("/\$DB_PASS\s*=\s*['\"]([^'\"]*)['\"];?/", $cfg, $m)) $dbPass = $m[1];
    if (preg_match("/\$DB_NAME\s*=\s*['\"]([^'\"]+)['\"];?/", $cfg, $m)) $dbName = $m[1];
}

echo "<h2>Initializing database using: host={$dbHost}, user={$dbUser}, db={$dbName}</h2>";

try {
    $pdo = new PDO("mysql:host={$dbHost};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "<p>Database <strong>{$dbName}</strong> ensured.</p>";

    // Use database
    $pdo->exec("USE `{$dbName}`");

    // Create tables
    $pdo->exec("CREATE TABLE IF NOT EXISTS activities (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    echo "<p>Table <strong>activities</strong> ensured.</p>";

    $pdo->exec("CREATE TABLE IF NOT EXISTS photos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      activity_id INT NOT NULL,
      filename VARCHAR(255) NOT NULL,
      uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    echo "<p>Table <strong>photos</strong> ensured.</p>";

    $pdo->exec("CREATE TABLE IF NOT EXISTS ratings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      activity_id INT NOT NULL,
      score TINYINT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    echo "<p>Table <strong>ratings</strong> ensured.</p>";

    // Insert sample data if activities empty
    $row = $pdo->query("SELECT COUNT(*) AS c FROM activities")->fetch();
    if (isset($row['c']) && $row['c'] == 0) {
        $pdo->exec("INSERT INTO activities (title, description) VALUES
            ('Activiteit A', 'Beschrijving A'),
            ('Activiteit B', 'Beschrijving B'),
            ('Activiteit C', 'Beschrijving C')");
        echo "<p>Inserted sample activities.</p>";
    } else {
        echo "<p>Activities table already has data (skipped sample insert).</p>";
    }

    echo "<p style='color:green'><strong>Setup complete.</strong></p>";
    echo "<p><a href=\"list.php\">Bekijk activiteiten</a></p>";

} catch (PDOException $e) {
    echo "<h3 style='color:red'>Error:</h3>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<p>If the error is Access denied, make sure the credentials in <code>config.php</code> match the MySQL server on your computer (ask your teacher if needed).</p>";
}
?>