<?php
$servername = "127.0.0.1"; // of "localhost"
$port = "3306";             // kijk in Workbench wat de poort is
$username = "root";
$password = "admin";     // dit moet overeenkomen met je MySQL wachtwoord
$dbname = "activiteiten_app";

try {
    $conn = new PDO("mysql:host=$servername;port=$port;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
