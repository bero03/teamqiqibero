<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: list.php'); exit; }
$activity_id = (int)($_POST['activity_id'] ?? 0);
$score = (int)($_POST['score'] ?? 0);
if ($activity_id <= 0 || $score < 1 || $score > 5) { header('Location: detail.php?id=' . $activity_id); exit; }
$stmt = $pdo->prepare("INSERT INTO ratings (activity_id, score) VALUES (?, ?)");
$stmt->execute([$activity_id, $score]);
header('Location: detail.php?id=' . $activity_id);
exit;
?>