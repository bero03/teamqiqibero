<?php
require 'config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { header('Location: list.php'); exit; }

// Get activity
$stmt = $pdo->prepare("SELECT a.*, COALESCE(AVG(r.score),0) AS avg_score FROM activities a LEFT JOIN ratings r ON r.activity_id=a.id WHERE a.id=? GROUP BY a.id");
$stmt->execute([$id]);
$activity = $stmt->fetch();
if (!$activity) { echo 'Activiteit niet gevonden'; exit; }

// get photos
$stmt = $pdo->prepare("SELECT * FROM photos WHERE activity_id=? ORDER BY id");
$stmt->execute([$id]);
$photos = $stmt->fetchAll();

// get ratings
$stmt = $pdo->prepare("SELECT score, created_at FROM ratings WHERE activity_id=? ORDER BY created_at DESC");
$stmt->execute([$id]);
$ratings = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?php echo htmlspecialchars($activity['title']); ?></title>
  <style>
    body{font-family:Arial;padding:20px}
    .gallery{display:flex;gap:8px;flex-wrap:wrap}
    .gallery img{width:240px;height:160px;object-fit:cover;border-radius:6px}
    .meta{margin-top:12px}
  </style>
</head>
<body>
  <a href="list.php">← Terug</a>
  <h1><?php echo htmlspecialchars($activity['title']); ?></h1>
  <div class="meta">Gem. score: <?php echo number_format($activity['avg_score'],2); ?></div>
  <p><?php echo nl2br(htmlspecialchars($activity['description'] ?? '')); ?></p>

  <h3>Foto's</h3>
  <div class="gallery">
    <?php if ($photos): foreach($photos as $p): ?>
      <img src="images/<?php echo htmlspecialchars($p['filename']); ?>" alt="">
    <?php endforeach; else: ?>
      <div>Geen foto's</div>
    <?php endif; ?>
  </div>

  <h3>Beoordelingen</h3>
  <?php if ($ratings): ?>
    <ul>
    <?php foreach($ratings as $r): ?>
      <li><?php echo htmlspecialchars($r['score']); ?> — <?php echo htmlspecialchars($r['created_at']); ?></li>
    <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p>Nog geen beoordelingen</p>
  <?php endif; ?>

  <h3>Laat een score achter</h3>
  <form method="post" action="rate.php">
    <input type="hidden" name="activity_id" value="<?php echo $id; ?>">
    <select name="score">
      <option value="5">5</option>
      <option value="4">4</option>
      <option value="3">3</option>
      <option value="2">2</option>
      <option value="1">1</option>
    </select>
    <button type="submit">Verstuur</button>
  </form>

</body>
</html>