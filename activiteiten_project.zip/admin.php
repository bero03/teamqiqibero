<?php
// admin.php - simple admin login/dashboard skeleton
// Usage:
//  - Preferred: create an admin user in the `users` table with role='admin' and a password_hash produced by password_hash().
//  - Fallback (development): set environment variables ADMIN_USER and ADMIN_PASS and the file will accept those.

require_once __DIR__ . '/config.php';
session_start();

function is_admin_logged_in(): bool {
    return !empty($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

$error = '';

// Handle login POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Vul gebruikersnaam en wachtwoord in.';
    } else {
        // Attempt DB-based auth (recommended)
        try {
            $db = get_db_connection();
            $stmt = $db->prepare("SELECT id, username, password_hash FROM users WHERE username = ? AND role = 'admin' LIMIT 1");
            if ($stmt) {
                $stmt->bind_param('s', $username);
                $stmt->execute();
                $res = $stmt->get_result();
                if ($row = $res->fetch_assoc()) {
                    if (password_verify($password, $row['password_hash'])) {
                        // success
                        $_SESSION['admin_logged_in'] = true;
                        $_SESSION['admin_user'] = $row['username'];
                        header('Location: admin.php');
                        exit;
                    } else {
                        $error = 'Onjuiste gebruikersnaam of wachtwoord.';
                    }
                } else {
                    $error = 'Admin gebruiker niet gevonden (DB).';
                }
                $stmt->close();
            } else {
                // prepare failed; fall through to env fallback
                $error = 'Database authenticatie niet beschikbaar.';
            }
            $db->close();
        } catch (Exception $e) {
            // If DB is not set up, fallback to environment variables for dev convenience
            $envUser = getenv('ADMIN_USER') ?: 'admin';
            $envPass = getenv('ADMIN_PASS') ?: 'admin';
            if ($username === $envUser && $password === $envPass) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_user'] = $username;
                header('Location: admin.php');
                exit;
            } else {
                $error = 'Onjuiste gebruikersnaam of wachtwoord.';
            }
        }
    }
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: admin.php');
    exit;
}

?>
<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Admin</title>
  <link rel="stylesheet" href="css/style.css">
  <style>.login-box{max-width:420px;margin:30px auto;padding:18px}.dash-links a{display:inline-block;margin-right:8px}</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Admin</h1>
      <div>
        <?php if (is_admin_logged_in()): ?>
          Ingelogd als <?php echo htmlspecialchars($_SESSION['admin_user']); ?> — <a href="?action=logout">Uitloggen</a>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!is_admin_logged_in()): ?>
      <div class="login-box">
        <h2>Inloggen</h2>
        <?php if ($error): ?>
          <div style="color:#b00;margin-bottom:10px"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post">
          <input type="hidden" name="action" value="login">
          <div class="form-row"><label>Gebruikersnaam</label><input type="text" name="username" required></div>
          <div class="form-row"><label>Wachtwoord</label><input type="password" name="password" required></div>
          <div class="form-row"><button type="submit">Login</button></div>
        </form>

        <p class="small">Ontbreekt een admin user in de database? Voor development kun je environment variables gebruiken:<br><code>ADMIN_USER</code> en <code>ADMIN_PASS</code>. Standaard zijn ze `admin`/`admin` (verander dit!).</p>
      </div>

    <?php else: ?>
      <div class="dash">
        <h2>Dashboard</h2>
        <p>Welkom, <?php echo htmlspecialchars($_SESSION['admin_user']); ?>. Gebruik de links hieronder om activiteiten te beheren.</p>
        <div class="dash-links">
          <a href="activity_add.php">Nieuwe activiteit toevoegen</a>
          <a href="index.php">Bekijk activiteiten</a>
          <a href="activity_manage.php">Beheer activiteiten</a>
        </div>
        <hr>
        <p class="small">Dit is een eenvoudige admin-skeleton. Je moet nog acties (create/update/delete) implementeren of beschermen door te controleren <code>is_admin_logged_in()</code> boven die scripts.</p>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
